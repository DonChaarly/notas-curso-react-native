import React, { useEffect } from 'react'
import { Button, Text } from 'react-native';

const MenuPrincipal = ({navigation}) => {

  return (
    <>
        <Text>En menu</Text> 
    </>
  )
}

export default MenuPrincipal;
